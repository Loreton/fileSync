# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 22-08-2020 09.35.05
#
# #############################################

import sys
import argparse
from pathlib import Path


def common_options(my_parser):
    my_parser.add_argument('------------  debug options', action='store_true')
    my_parser.add_argument('--go', action='store_true', help='default is --dry-run')
    my_parser.add_argument('--display-args', action='store_true', help='Display input paramenters')
    my_parser.add_argument('--debug', action='store_true',
                                help='''display paths and input args\n\n'''+C.gGreen())










##############################################################
# - MAin Options
##############################################################
def mainOptions(parser, profiles):
    subparsers=parser.add_subparsers(title="primary commands",
                                    dest='action',
                                    help='commands')

    # - list parser
    list_parser=subparsers.add_parser("list",
                        formatter_class=argparse.RawTextHelpFormatter,
                        help="LnDisk process")

    list_parser.add_argument('--servers', action='store_true', help='list of servers in config file')
    list_parser.add_argument('--profiles', action='store_true', help='list of profiles in config file')
    list_parser.add_argument('--directories', action='store_true', help='list of directories in config file')

    # - profile parser
    profile_parser=subparsers.add_parser("profile",
                        formatter_class=argparse.RawTextHelpFormatter,
                        help="copy LnDisk data to LnPi31")

    profile_parser.add_argument('--name', type=str,
                            required=True,
                            choices=profiles,
                            help='Profile name.')

    profile_parser.add_argument('--sub-folders', type=str,
                            required=False,
                            default=[],
                            nargs='*',
                            help='enter subfolders blank separator.\n'+C.gGreen())

    # -- add common options to all subparsers
    for name, subp in subparsers.choices.items():
        common_options(subp)


def post_process(args):
    # separazione degli args di tipo debug con quelli applicativi
    dbg=argparse.Namespace()
    log=argparse.Namespace()

    '''
    il processo che segue è per evitare:
       RuntimeError: dictionary changed size during iteration
       suddividiamo le varie options
    '''
    keys=list(args.__dict__.keys())
    # _dargs=args.__dict__
    for key in keys:
        val=getattr(args, key)
        if key in ['log']:
            setattr(log, key, val)
        elif key.startswith('log_'):
            setattr(log, key[4:], val)
        elif key.startswith('+log'):
            pass # le ignoro in quanto servono solo ad impostare il valore
        elif key in ['go', 'debug']:
            setattr(dbg, key, val)
        elif 'debug options' in key:
            pass
        elif 'log options' in key:
            pass
        else:
            continue

        delattr(args, key)

    app=args


    if args.display_args:
        del args.display_args
        import json
        json_data = json.dumps(vars(app), indent=4, sort_keys=True)
        print('application arguments: {json_data}'.format(**locals()))
        json_data = json.dumps(vars(log), indent=4, sort_keys=True)
        print('logging arguments: {json_data}'.format(**locals()))
        json_data = json.dumps(vars(dbg), indent=4, sort_keys=True)
        print('debugging arguments: {json_data}'.format(**locals()))
        sys.exit(0)

    return app, log, dbg

##############################################################
# - Parse Input
##############################################################
def parseInput(profiles, color=None):
    global C
    C=color

    # =============================================
    # = Parsing
    # =============================================
    if len(sys.argv) == 1: sys.argv.append('-h')
    parser=argparse.ArgumentParser(
                description='Program to help mounting USB-disk on Raspberry (by: Ln)'+C.gYellow(),
                formatter_class=argparse.RawTextHelpFormatter)
    mainOptions(parser, profiles)

    args=parser.parse_args()
    return post_process(args)

