#!/usr/bin/python3

# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 21-08-2020 16.05.13
#
# #############################################

import sys; sys.dont_write_bytecode=True
import subprocess, shlex


##################################################
# _alias_exec
##################################################
def runCommand_noWait(command, logger=None, fPRINT=False, exitOnError=False):
    splitted_cmd=shlex.split(command) if isinstance(command, str) else command
    p=subprocess.Popen(command, close_fds=True)

def runCommand(command, logger=None, fPRINT=False, exitOnError=False):
    splitted_cmd=shlex.split(command) if isinstance(command, str) else command

    if logger: logger.info('executing command:', "", command)
    if fPRINT: print('executing command:', "", splitted_cmd)

    try:
        p1=subprocess.run(splitted_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    universal_newlines=True,
                    check=True)
        if logger:
            logger.info('    rcode: ', p1.returncode)
            logger.debug1('    result:', p1.stdout)

        if fPRINT:
            print('    rcode: ', p1.returncode)
            print('    result:', p1.stdout)


        return p1.returncode, p1.stdout

    except subprocess.CalledProcessError as e:
        if logger:
            logger.error("ERROR:", "",
                              f"command:   {command}",
                              f"rcode:     {e.returncode}",
                              f"stdout:    {e.stdout.strip()}",
                              f"exception: {str(e)}")

        if fPRINT or exitOnError:
            print(f"""ERROR:
                      f"command:   {command}",
                      f"rcode:     {e.returncode}",
                      f"stdout:    {e.stdout.strip()}",
                      f"exception: {str(e)}""")

        if exitOnError:
            sys.exit()

        return e.returncode, e.stdout.strip()



def wsl_to_win_path(wsl_path):
    rcode, win_path=runCommand(f'wslpath -m -a "{wsl_path}"', exitOnError=True)
    return win_path.strip().strip('\n').strip()