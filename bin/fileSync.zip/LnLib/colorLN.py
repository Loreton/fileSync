#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# updated by ...: Loreto Notarantonio
# Version ......: 18-08-2020 08.54.26
# Updates:
#   06-07-2020: messo il controllo sul text di tipo pathlib
# #########################################################
import sys, os


# from . import colorama_039 as colorama
from . import colorama_043 as colorama
import pathlib


class LnColor:
    colorama.init(wrap=True, convert=None, strip=None, autoreset=False)
    # for i in dir('LnColors'): print (i)
    '''
        devo mantenere i valori seguenti perché a volte
        devo mandare una stringa pronta con il colore e non posso usare il printColor(msg) oppure il getColor()
        in quanto ho una stringa multicolor
        usageMsg = " {COLOR}   {TEXT} {COLRESET}[options]".format(COLOR=C.YEL, TEXE='Loreto', COLRESET=C.RESET)

    '''
    FG         = colorama.Fore
    BG         = colorama.Back
    HI         = colorama.Style

    _black       = FG.BLACK
    _red         = FG.RED              ; _redH     = _red     + HI.BRIGHT
    _green       = colorama.Fore.GREEN ; _greenH   = _green   + HI.BRIGHT
    _yellow      = FG.YELLOW           ; _yellowH  = _yellow  + HI.BRIGHT
    _blue        = FG.BLUE             ; _blueH    = _blue    + HI.BRIGHT
    _magenta     = FG.MAGENTA          ; _magentaH = _magenta + HI.BRIGHT
    _cyan        = FG.CYAN             ; _cyanH    = _cyan    + HI.BRIGHT
    _white       = FG.WHITE            ; _whiteH   = _white   + HI.BRIGHT

    RESET        = HI.RESET_ALL
    BW           = FG.BLACK + BG.WHITE
    BWH          = FG.BLACK + BG.WHITE + HI.BRIGHT
    YellowOnBlask = FG.BLACK + BG.YELLOW

    _default = HI.RESET_ALL + FG.WHITE + BG.BLACK
    _reset = _default
    callerFunc = sys._getframe(1).f_code.co_name




    def __init__(self, filename=None):
        self._stdout = None
        self._stdout_colored = None
        self.colored_text = ''
        self.normal_text  = ''

        if filename:
            name,ext = filename.rsplit('.',1)
            colored_filename = name + '_colored.' + ext

            self._stdout = open(filename, "w", encoding='utf-8')
            self._stdout_colored = open(colored_filename, "w", encoding='utf-8')


    def setColor(self,  color=''):
        print (self._default + color, end='' )

    def getColored(self, text='', **args):
        self._prepareText (text=text, **args)
        return self.colored_text


    def toFile(self, end):
        if self._stdout:
            self._stdout.write('{0}{1}'.format(self.normal_text, end))
            self._stdout.flush()

        if self._stdout_colored:
            self._stdout_colored.write('{0}{1}'.format(self.colored_text, end))
            self._stdout_colored.flush()


    # - il return mi server per il get=True
    def pResetColor(self, text='', **args):   return self.pprint(text, color=self._default, **args)
    def pError(self, text='', **args):        return self.pprint(text, color=self._redH, **args)
    def pWarning(self, text='', **args):      return self.pprint(text, color=self._magentaH, **args)

    # - print colored
    def pWhite(self, text='', **args):        return self.pprint(text, color=self._white, **args)
    def pYellow(self, text='', **args):       return self.pprint(text, color=self._yellow, **args)
    def pCyan(self, text='', **args):         return self.pprint(text, color=self._cyan, **args)
    def pMagenta(self, text='', **args):      return self.pprint(text, color=self._magenta, **args)
    def pRed(self, text='', **args):          return self.pprint(text, color=self._red, **args)
    def pGreen(self, text='', **args):        return self.pprint(text, color=self._green, **args)
    def pBlue(self, text='', **args):         return self.pprint(text, color=self._blue, **args)

    def pWhiteH(self, text='', **args):       return self.pprint(text, color=self._whiteH, **args)
    def pYellowH(self, text='', **args):      return self.pprint(text, color=self._yellowH, **args)
    def pCyanH(self, text='', **args):        return self.pprint(text, color=self._cyanH, **args)
    def pMagentaH(self, text='', **args):     return self.pprint(text, color=self._magentaH, **args)
    def pRedH(self, text='', **args):         return self.pprint(text, color=self._redH, **args)
    def pGreenH(self, text='', **args):       return self.pprint(text, color=self._greenH, **args)
    def pBlueH(self, text='', **args):        return self.pprint(text, color=self._blueH, **args)

    # - back compatibility
    # pWhite=printWhite
    # pYellow=printYellow
    # pCyan=printCyan
    # pMagenta=printMagenta
    # pRed=printRed
    # pGreen=printGreen
    # pBlue=printBlue
    # pWhiteH=printWhiteH
    # pYellowH=printYellowH
    # pCyanH=printCyanH
    # pMagentaH=printMagentaH
    # pRedH=printRedH
    # pGreenH=printGreenH
    # pBlueH=printBlueH

    # - get colored
    def gWhite(self, text='', **args):        return self.getColored(text=text, color=self._white, **args)
    def gYellow(self, text='', **args):       return self.getColored(text=text, color=self._yellow, **args)
    def gCyan(self, text='', **args):         return self.getColored(text=text, color=self._cyan, **args)
    def gMagenta(self, text='', **args):      return self.getColored(text=text, color=self._magenta, **args)
    def gRed(self, text='', **args):          return self.getColored(text=text, color=self._red, **args)
    def gGreen(self, text='', **args):        return self.getColored(text=text, color=self._green, **args)
    def gBlue(self, text='', **args):         return self.getColored(text=text, color=self._blue, **args)

    def gWhiteH(self, text='', **args):       return self.getColored(text=text, color=self._whiteH, **args)
    def gYellowH(self, text='', **args):      return self.getColored(text=text, color=self._yellowH, **args)
    def gCyanH(self, text='', **args):        return self.getColored(text=text, color=self._cyanH, **args)
    def gMagentaH(self, text='', **args):     return self.getColored(text=text, color=self._magentaH, **args)
    def gRedH(self, text='', **args):         return self.getColored(text=text, color=self._redH, **args)
    def gGreenH(self, text='', **args):       return self.getColored(text=text, color=self._greenH, **args)
    def gBlueH(self, text='', **args):        return self.getColored(text=text, color=self._blueH, **args)



        # ----------------------------------------------
        # - print
        # ----------------------------------------------
    def pprint(self, text='', end='\n', autoreset=True, toFile=False, **args):
        self._prepareText (text=text, **args)
        # if get==True:
        #     return self.colored_text + self._default

        try:
            print (self.colored_text, end=end )

        except (UnicodeEncodeError):
            print ('{0} function: {1} - UnicodeEncodeError on next line {2}'.format(
                    LnColor.redH,
                    _function_name),
                end=end )
            print (self.normal_text.encode(string_encode, 'ignore'), end=end )


        if autoreset:
            print(self._default, end='')

        if toFile:
            self.toFile(end=end)

        self.colored_text = ''
        self.normal_text  = ''



    def _prepareText(self, color='', text='', tab=0, string_encode='latin-1'):
        if isinstance(text, (pathlib.PosixPath)):
            text=str(text)

        _function_name = sys._getframe().f_code.co_name
        thisTAB = ' '*tab
        # if not isinstance(text, str):
            # text = str(text)
        # ----------------------------------------------
        # - intercettazione del tipo text per fare un
        # - print più intelligente.
        # ----------------------------------------------

            # - convertiamo list in string (con il tab in ogni riga)
        if isinstance(text, (list, tuple)):
            myMsg = [text[0]]
            for line in text[1:]:
                myMsg.append('{0}{1}'.format(thisTAB, line.strip()))
            text = '\n'.join(myMsg)
            thisTAB = ''

        elif '\n' in text:
            '''
                cerchiamo la prima riga valida
                in essa contiamo i BLANK fino al primo char
                ci serve per eliminare tale spazio alle linee successive
                in modo da mantenere l'indentazione
            '''
            _text=text.split('\n')
            myMsg = []
            first_char=0
            for line in _text:
                if not myMsg: # cerchiamo prima entry valida
                    if line.strip():
                        first_char=len(line) - len(line.lstrip())
                        myMsg.append('{0}{1}'.format(thisTAB, line.strip()))
                else:
                    myMsg.append('{0}{1}'.format(thisTAB, line[first_char:]))

            text = '\n'.join(myMsg)
            thisTAB = ''

            # - convertiamo bytes in string
        if isinstance(text, bytes):
            text = text.decode('utf-8')


        self.colored_text = '{0}{1}{2}'.format(thisTAB, color, text)
        self.normal_text  = '{0}{1}'.format(thisTAB, text)
